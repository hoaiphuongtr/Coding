const sum = (num1, num2) => num1 + num2;
export default sum;
